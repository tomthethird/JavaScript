const listOfDogs = [
    {
        name: 'Sushi',
        age: 1,
        img: "QuizB2_DogAdoption Photos/dog1.jpg",
        toys: ["bone", "water bottle"],
    },
    {
        name: 'Dosan',
        age: 3,
        img: "QuizB2_DogAdoption Photos/dog2.jpg",
        toys: ["ball", "shoes"],
    },
    {
        name: 'Bizkit',
        age: 4,
        img: "QuizB2_DogAdoption Photos/dog3.jpg",
        toys: ["rubber duck", "slippers"],
    },
]

function toDogYears(age){
    if (age <= 2){
        let dogAge = age * 10.5
        return dogAge
    } else {
        let dogAge = 21 + (age-2)*4
        return dogAge
    }
}

let dogs = document.getElementById("dogs")

for (const dog of listOfDogs) {
    // create a container div
    const container = document.createElement("div")
    container.id = "container"

    // create name child for container
    const nameContainer = document.createElement("h2")
    const name = document.createTextNode(`${dog.name}`)
    nameContainer.appendChild(name)
    
    // create age child for container
    const ageContainer = document.createElement("h3")
    const age = document.createTextNode(`${toDogYears(dog.age)} dog-years-old`)
    const agedscptContainer = document.createElement("h4")
    const agedscpt = document.createTextNode(`${dog.age} human-year-old`)
    ageContainer.appendChild(age)
    agedscptContainer.appendChild(agedscpt)

    // create imgage container
    const imageContainer = document.createElement("img")
    imageContainer.src=(dog.img)
    
    // create toys child for container
    const toysContainer = document.createElement("h3")
    const toys = document.createTextNode(`${dog.toys}`)
    const favetoyContainer = document.createElement("h4")
    const favetoy = document.createTextNode(`FAVORITE TOYS`)
    toysContainer.appendChild(toys)
    favetoyContainer.appendChild(favetoy)
    
    // Parent children to container
    container.appendChild(nameContainer)
    container.appendChild(ageContainer)
    container.appendChild(agedscptContainer)
    container.appendChild(imageContainer)
    container.appendChild(toysContainer)
    container.appendChild(favetoyContainer)

    // Append to dogs container
    dogs.appendChild(container)
}

console.table(listOfDogs)